/* ==========================================================================
   Haj Abdollah — smooth scroll, navigation, section animations, contact form
   ========================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;
  var gsap = window.gsap;
  var ScrollTrigger = window.ScrollTrigger;
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var motion = !!(gsap && ScrollTrigger) && !reduceMotion;

  var FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
  var AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
  function toFa(n) {
    return String(n).replace(/\d/g, function (d) { return FA_DIGITS[d]; });
  }
  function toLatinDigits(s) {
    return s
      .replace(/[۰-۹]/g, function (d) { return FA_DIGITS.indexOf(d); })
      .replace(/[٠-٩]/g, function (d) { return AR_DIGITS.indexOf(d); });
  }

  if (gsap && ScrollTrigger) gsap.registerPlugin(ScrollTrigger);

  // Reloading mid-story would land inside the pinned hero with stale measurements; start from the top.
  if ('scrollRestoration' in history && location.hash.length < 2) {
    history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);
  }

  /* ---------- Smooth scroll (Lenis) ---------- */

  // Disabled for prefers-reduced-motion (motion === false). Touch keeps native scrolling:
  // phones and tablets skip Lenis entirely, because even with syncTouch off it registers
  // non-passive touch listeners, which make every touch scroll wait on the main thread.
  var lenis = null;
  var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  if (motion && finePointer && window.Lenis) {
    lenis = new window.Lenis({
      lerp: 0.07,              // slow, heavy glide
      smoothWheel: true,
      wheelMultiplier: 0.9,
      syncTouch: false         // forced smoothing on touch feels laggy on iOS/Android
    });
    lenis.on('scroll', ScrollTrigger.update);
    // GSAP's ticker is the only rAF loop: Lenis runs first each tick (prioritized),
    // then ScrollTrigger and the hero playhead (sequence.js) see the same scroll value.
    gsap.ticker.add(function (time) { lenis.raf(time * 1000); }, false, true);
    gsap.ticker.lagSmoothing(0);
  }

  function expoOut(t) { return t === 1 ? 1 : 1 - Math.pow(2, -10 * t); }

  function scrollToEl(el) {
    var top = el.id === 'top';
    if (lenis) {
      lenis.scrollTo(top ? 0 : el, { duration: 1.8, easing: expoOut });
    } else if (top) {
      window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    } else {
      el.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' });
    }
    // Move keyboard focus with the jump, without a second scroll.
    if (!top) {
      if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1');
      el.focus({ preventScroll: true });
    }
  }

  /* ---------- Header ---------- */

  var header = document.querySelector('[data-header]');
  var hero = document.querySelector('[data-hero]');

  // Transparent while the hero is on screen (including its pinned stretch), solid after.
  if (header && hero && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      header.classList.toggle('is-solid', !entries[0].isIntersecting);
    }, { rootMargin: '-60px 0px 0px 0px' }).observe(hero);
  } else if (header) {
    header.classList.add('is-solid');
  }

  /* ---------- Mobile menu ---------- */

  var menu = document.querySelector('[data-menu]');
  var toggle = document.querySelector('[data-menu-toggle]');
  var toggleLabel = document.querySelector('[data-menu-label]');
  var menuLinks = menu ? Array.prototype.slice.call(menu.querySelectorAll('a')) : [];
  var menuOpen = false;

  function openMenu() {
    menuOpen = true;
    menu.hidden = false;
    toggle.setAttribute('aria-expanded', 'true');
    toggleLabel.textContent = 'بستن منو';
    root.classList.add('menu-open');
    if (lenis) lenis.stop(); else document.body.style.overflow = 'hidden';

    if (motion) {
      gsap.killTweensOf([menu].concat(menuLinks));
      gsap.fromTo(menu, { opacity: 0 }, { opacity: 1, duration: 0.5, ease: 'power3.out' });
      gsap.fromTo(menu.querySelectorAll('.menu__list li'),
        { y: 44, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, ease: 'expo.out', stagger: 0.06, delay: 0.08 });
      gsap.fromTo(menu.querySelector('.menu__foot'),
        { opacity: 0 }, { opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.4 });
    }
    menuLinks[0].focus({ preventScroll: true });
  }

  function closeMenu(restoreFocus) {
    if (!menuOpen) return;
    menuOpen = false;
    toggle.setAttribute('aria-expanded', 'false');
    toggleLabel.textContent = 'باز کردن منو';
    root.classList.remove('menu-open');
    if (lenis) lenis.start(); else document.body.style.overflow = '';

    var hide = function () { if (!menuOpen) menu.hidden = true; };
    if (motion) gsap.to(menu, { opacity: 0, duration: 0.35, ease: 'power2.out', onComplete: hide });
    else hide();
    if (restoreFocus) toggle.focus();
  }

  if (menu && toggle) {
    toggle.addEventListener('click', function () {
      if (menuOpen) closeMenu(true); else openMenu();
    });

    document.addEventListener('keydown', function (e) {
      if (!menuOpen) return;
      if (e.key === 'Escape') { closeMenu(true); return; }
      if (e.key !== 'Tab') return;
      // Keep focus inside the toggle + menu while open.
      var items = [toggle].concat(menuLinks);
      var i = items.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); items[items.length - 1].focus(); }
      else if (!e.shiftKey && i === items.length - 1) { e.preventDefault(); items[0].focus(); }
    });

    window.matchMedia('(min-width: 900px)').addEventListener('change', function (mq) {
      if (mq.matches) closeMenu(false);
    });
  }

  /* ---------- In-page links ---------- */

  var inquirySelect = document.getElementById('f-type');

  document.addEventListener('click', function (e) {
    var link = e.target.closest('a[href^="#"]');
    if (!link) return;
    var id = link.getAttribute('href').slice(1);
    var target = id && document.getElementById(id);
    if (!target) return;
    e.preventDefault();

    var inquiry = link.getAttribute('data-inquiry');
    if (inquiry && inquirySelect) {
      inquirySelect.value = inquiry;
      inquirySelect.dispatchEvent(new Event('change'));
    }

    if (menuOpen) closeMenu(false);
    scrollToEl(target);
    if (history.replaceState) history.replaceState(null, '', id === 'top' ? location.pathname : '#' + id);
  });

  /* ---------- Reveal animations ---------- */

  if (motion) {
    // Headlines: line by line.
    document.querySelectorAll('[data-lines]').forEach(function (el) {
      gsap.from(el.querySelectorAll('.line'), {
        y: 44,
        opacity: 0,
        duration: 1.3,
        ease: 'power3.out',
        stagger: 0.14,
        scrollTrigger: { trigger: el, start: 'top 86%', once: true }
      });
    });

    // Everything else: a slow rise.
    document.querySelectorAll('[data-reveal]').forEach(function (el) {
      gsap.from(el, {
        y: 48,
        opacity: 0,
        duration: 1.4,
        ease: 'expo.out',
        clearProps: 'transform,opacity',   // hand hover transforms back to CSS
        scrollTrigger: { trigger: el, start: 'top 90%', once: true }
      });
    });
  }

  /* ---------- Story: statement reveals word by word ---------- */

  var statement = document.querySelector('[data-words]');
  if (statement && motion) {
    var words = statement.textContent.trim().split(/\s+/);
    statement.setAttribute('aria-label', statement.textContent.trim());
    statement.innerHTML = words.map(function (w) {
      return '<span class="word" aria-hidden="true">' + w + '</span>';
    }).join(' ');

    // Layer promotion only while the section is in view (see .is-revealing in style.css).
    ScrollTrigger.create({ trigger: '.story', start: 'top bottom', end: 'bottom top', toggleClass: 'is-revealing' });

    var tl = gsap.timeline({
      scrollTrigger: {
        trigger: '.story',
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0.6
      }
    });
    tl.fromTo(statement.querySelectorAll('.word'),
      { opacity: 0.16 },
      { opacity: 1, ease: 'none', stagger: 0.12, duration: 0.5 })
      .fromTo('.story__lead', { opacity: 0, y: 32 }, { opacity: 1, y: 0, ease: 'power2.out', duration: 0.9 }, '+=0.15')
      .to({}, { duration: 0.6 }); // a beat of stillness before the section releases
  }

  /* ---------- Craft: active step drives the pinned image ---------- */

  var steps = document.querySelectorAll('.craft__step');
  var stepImgs = document.querySelectorAll('[data-step-img]');
  function setStep(i) {
    steps.forEach(function (s, k) { s.classList.toggle('is-active', k === i); });
    stepImgs.forEach(function (img, k) { img.classList.toggle('is-active', k === i); });
  }
  if (steps.length && 'IntersectionObserver' in window) {
    setStep(0);
    var stepObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) setStep(Array.prototype.indexOf.call(steps, entry.target));
      });
    }, { rootMargin: '-58% 0px -38% 0px' });   // a thin reading line just below the middle
    steps.forEach(function (s) { stepObserver.observe(s); });
  }

  /* ---------- Numbers ---------- */

  var counters = document.querySelectorAll('[data-count]');
  if (counters.length && motion && 'IntersectionObserver' in window) {
    counters.forEach(function (el) { el.textContent = toFa(0); });
    var countObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        countObserver.unobserve(entry.target);
        var el = entry.target;
        var state = { v: 0 };
        gsap.to(state, {
          v: parseFloat(el.getAttribute('data-count')) || 0,
          duration: 2.4,
          ease: 'power3.out',
          onUpdate: function () { el.textContent = toFa(Math.round(state.v)); }
        });
      });
    }, { threshold: 0.6 });
    counters.forEach(function (el) { countObserver.observe(el); });
  }

  /* ---------- Contact form ---------- */

  var form = document.querySelector('[data-form]');
  if (form) {
    var status = form.querySelector('[data-form-status]');
    var submitBtn = form.querySelector('[type="submit"]');
    var submitLabel = submitBtn.textContent;
    var attempted = false;

    // Iranian mobile (09…, +989…, 00989…) or landline (0 + area code + number).
    var PHONE_RE = /^(?:(?:\+98|0098|0)9\d{9}|0[1-8]\d{9})$/;

    var rules = {
      name: function (v) {
        if (!v) return 'لطفاً نام و نام خانوادگی خود را وارد کنید.';
        if (v.length < 2) return 'نام باید دست‌کم ۲ حرف باشد.';
        return '';
      },
      phone: function (v) {
        if (!v) return 'لطفاً شماره تماس خود را وارد کنید.';
        if (!PHONE_RE.test(toLatinDigits(v).replace(/[\s\-().]/g, ''))) {
          return 'شماره تماس معتبر نیست؛ برای نمونه: ۰۹۱۲۳۴۵۶۷۸۹';
        }
        return '';
      },
      city: function (v) {
        return v ? '' : 'لطفاً شهر خود را وارد کنید.';
      },
      type: function (v) {
        return v ? '' : 'لطفاً نوع درخواست را انتخاب کنید.';
      },
      message: function (v) {
        if (!v) return 'لطفاً پیام خود را بنویسید.';
        if (v.length < 10) return 'پیام باید دست‌کم ۱۰ حرف باشد.';
        return '';
      }
    };

    function validateField(field) {
      var rule = rules[field.name];
      if (!rule) return true;
      var msg = rule((field.value || '').trim());
      var err = document.getElementById(field.getAttribute('aria-describedby'));
      field.setAttribute('aria-invalid', msg ? 'true' : 'false');
      if (err) err.textContent = msg;
      return !msg;
    }

    function setStatus(text, isError) {
      status.textContent = text;
      status.classList.toggle('is-error', !!isError);
    }

    Array.prototype.forEach.call(form.elements, function (field) {
      if (!rules[field.name]) return;
      field.addEventListener('blur', function () {
        if (attempted || field.value) validateField(field);
      });
      field.addEventListener('input', function () {
        if (field.getAttribute('aria-invalid') === 'true') validateField(field);
      });
      field.addEventListener('change', function () {
        if (field.tagName === 'SELECT' && (attempted || field.value)) validateField(field);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      attempted = true;

      var firstInvalid = null;
      Array.prototype.forEach.call(form.elements, function (field) {
        if (rules[field.name] && !validateField(field) && !firstInvalid) firstInvalid = field;
      });
      if (firstInvalid) {
        setStatus('لطفاً موارد مشخص‌شده را بررسی کنید.', true);
        firstInvalid.focus();
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'در حال ارسال…';
      setStatus('');

      var endpoint = form.getAttribute('data-endpoint');
      var request = endpoint
        ? fetch(endpoint, {
            method: 'POST',
            body: new FormData(form),
            headers: { Accept: 'application/json' }
          }).then(function (res) { if (!res.ok) throw new Error(res.status); })
        // Demo mode: no endpoint configured, nothing leaves the browser.
        : new Promise(function (resolve) { setTimeout(resolve, 700); });

      request.then(function () {
        form.reset();
        attempted = false;
        setStatus('سپاس از شما. درخواستتان ثبت شد و به‌زودی با شما تماس می‌گیریم.');
      }).catch(function () {
        setStatus('ارسال با خطا روبه‌رو شد. لطفاً دوباره تلاش کنید یا با ما تماس بگیرید.', true);
      }).then(function () {
        submitBtn.disabled = false;
        submitBtn.textContent = submitLabel;
      });
    });
  }

  /* ---------- Settle layout ---------- */

  /* ---------- Warm up below-the-fold images ---------- */

  // Lazy images would otherwise arrive and decode mid-scroll, right after the hero,
  // costing a burst of frames. Once every hero frame is in and the browser is idle,
  // fetch and decode them ahead of time instead.
  var allFrames = window.HajHero ? window.HajHero.allFrames : Promise.resolve();
  allFrames.then(function () {
    var idle = window.requestIdleCallback || function (fn) { return setTimeout(fn, 200); };
    idle(function () {
      document.querySelectorAll('img[loading="lazy"]').forEach(function (img) {
        img.loading = 'eager';
        if (img.decode) img.decode().catch(function () {});
      });
    }, { timeout: 3000 });
  });

  // One ScrollTrigger.refresh(), once fonts and the first hero frame are in
  // (with a timeout so a failed frame can never hold it back).
  if (gsap && ScrollTrigger) {
    var fontsReady = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
    var heroReady = window.HajHero ? window.HajHero.firstFrame : Promise.resolve();
    var timeout = new Promise(function (r) { setTimeout(r, 5000); });

    Promise.race([Promise.all([fontsReady, heroReady]), timeout]).then(function () {
      ScrollTrigger.refresh();

      // Deep links (#contact etc.): jump once pin spacers have their final size.
      var deep = location.hash.length > 1 && document.getElementById(location.hash.slice(1));
      if (deep) {
        if (lenis) lenis.scrollTo(deep, { immediate: true });
        else deep.scrollIntoView();
      }
    });
  }
})();
