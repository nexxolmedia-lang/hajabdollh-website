/* ==========================================================================
   Haj Abdollah — hero image-sequence scrubber
   Scroll progress → target frame → lerped playhead → canvas.

   Frames are fetched as compressed blobs and decoded off the main thread into
   ImageBitmaps that are already cropped and scaled to the visible canvas area,
   so a draw is a plain 1:1 blit: no decoding, no resampling mid-scroll.
   Only a window of bitmaps around the playhead is kept in memory.
   ========================================================================== */
(function () {
  'use strict';

  var FRAME_COUNT = 240;
  var LAST = FRAME_COUNT - 1;
  var DPR_CAP = 2;
  var DESKTOP_QUERY = '(min-width: 900px)';  // keep in sync with <link rel="preload"> in index.html
  var PORTRAIT_WIDTH_SHARE = 0.65;            // portrait: this share of the frame width fills the screen
  var PIN_DISTANCE = 5;                       // pinned scroll length, in viewport heights
  var SMOOTHING = 0.12;                       // lerp factor per 60fps tick (scaled by real delta time)
  var READY_COUNT = 64;                       // frames fetched before the loader steps aside
  var FETCH_CONCURRENCY = 6;
  var NEAR_RANGE = 24;                        // fetch frames this close to the playhead first
  var DECODE_CONCURRENCY = 4;
  var RESIZE_DEBOUNCE = 160;                  // ms

  var root = document.documentElement;
  var hero = document.querySelector('[data-hero]');
  if (!hero) return;

  var canvas = hero.querySelector('.hero__canvas');
  // Transparent canvas: it paints only the frame, never a background colour (see style.css).
  var ctx = canvas.getContext('2d');
  var loader = hero.querySelector('.hero__loader');
  var loaderBar = hero.querySelector('.hero__loader-bar');
  var loaderValue = hero.querySelector('.hero__loader-value');

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var canScrub = !reduceMotion && window.gsap && window.ScrollTrigger;
  if (!canScrub) {
    root.classList.remove('scrub');
    root.classList.add('static-hero');
  }

  var set = window.matchMedia(DESKTOP_QUERY).matches ? 'desktop' : 'mobile';
  var BITMAP_BUDGET = (set === 'desktop' ? 160 : 80) * 1024 * 1024;   // bytes of decoded frames kept
  var hasBitmaps = typeof window.createImageBitmap === 'function';

  function frameSrc(i) {
    return 'assets/sequence/' + set + '/' + String(i + 1).padStart(4, '0') + '.webp';
  }

  var FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
  function toFa(n) {
    return String(n).replace(/\d/g, function (d) { return FA_DIGITS[d]; });
  }

  // main.js waits on this (plus fonts) for its single ScrollTrigger.refresh().
  // main.js also waits on allFrames before warming up the images further down the page.
  var resolveFirstFrame, resolveAllFrames;
  window.HajHero = {
    firstFrame: new Promise(function (r) { resolveFirstFrame = r; }),
    allFrames: new Promise(function (r) { resolveAllFrames = r; })
  };

  /* ---------- Playhead state ---------- */

  var target = 0, current = 0;
  var direction = 1;            // last scroll direction, biases loading and decoding
  var drawn = -1;

  /* ---------- Fetching (compressed sources) ---------- */

  var sources = new Array(FRAME_COUNT);   // Blob, or a decoded <img> where fetch is unavailable
  var requested = new Uint8Array(FRAME_COUNT);
  var iw = 0, ih = 0;                     // natural frame size
  var settledCount = 0;
  var isReady = false;
  var order = loadOrder(), orderPos = 0;

  // Coarse-to-fine: every 16th frame, then 8th, 4th, 2nd, then the rest.
  function loadOrder() {
    var list = [], seen = new Uint8Array(FRAME_COUNT);
    [16, 8, 4, 2, 1].forEach(function (step) {
      for (var i = 0; i < FRAME_COUNT; i += step) {
        if (!seen[i]) { seen[i] = 1; list.push(i); }
      }
      if (!seen[LAST]) { seen[LAST] = 1; list.push(LAST); }
    });
    return list;
  }

  // Frames around the playhead first (ahead before behind), then coarse-to-fine coverage.
  function nextToFetch() {
    var c = Math.round(current);
    for (var d = 0; d <= NEAR_RANGE; d++) {
      var a = c + d * direction, b = c - d * direction;
      if (a >= 0 && a <= LAST && !requested[a]) return a;
      if (d && b >= 0 && b <= LAST && !requested[b]) return b;
    }
    while (orderPos < order.length && requested[order[orderPos]]) orderPos++;
    return orderPos < order.length ? order[orderPos] : -1;
  }

  function fetchWorker() {
    var i = nextToFetch();
    if (i < 0) return;
    requested[i] = 1;
    fetchFrame(i).then(fetchWorker);
  }

  function loadAsImage(i) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.decoding = 'async';
      img.onload = function () { (img.decode ? img.decode() : Promise.resolve()).then(function () { resolve(img); }, function () { resolve(img); }); };
      img.onerror = reject;
      img.src = frameSrc(i);
    });
  }

  function fetchFrame(i) {
    var get = (hasBitmaps && window.fetch)
      ? fetch(frameSrc(i)).then(function (r) {
          if (!r.ok) throw new Error(r.status);
          return r.blob();
        }).catch(function () { return loadAsImage(i); })   // e.g. opened from file://
      : loadAsImage(i);

    return get.then(function (src) {
      sources[i] = src;
      if (!iw) return measure(src).then(function () { onSourceLoaded(i); });
      onSourceLoaded(i);
    }, function () { onSettled(); });
  }

  // Natural size comes from the first frame; layout needs it before anything can be drawn.
  function measure(src) {
    if (src.naturalWidth) { iw = src.naturalWidth; ih = src.naturalHeight; layout(); return Promise.resolve(); }
    return createImageBitmap(src).then(function (bmp) {
      iw = bmp.width; ih = bmp.height; bmp.close(); layout();
    });
  }

  function onSourceLoaded(i) {
    onSettled();
    if (i >= winLo && i <= winHi) pumpDecodes();
  }

  function onSettled() {
    settledCount++;
    if (settledCount === FRAME_COUNT || !canScrub) resolveAllFrames();
    if (isReady || !loader) return;
    var p = Math.min(1, settledCount / READY_COUNT);
    loaderBar.style.transform = 'scaleX(' + p + ')';
    loaderValue.textContent = toFa(Math.round(p * 100)) + '٪';
    if (p >= 1) {
      isReady = true;
      loader.classList.add('is-done');
      hero.classList.add('is-ready');
    }
  }

  /* ---------- Layout (resize only) ---------- */

  var dpr = 1, cssW = 0, cssH = 0;
  var sx = 0, sy = 0, sw = 0, sh = 0;   // visible part of the frame, in source pixels
  var bx = 0, by = 0, bw = 0, bh = 0;   // where it lands on the canvas, in device pixels
  var maxBitmaps = 24;

  function layout() {
    var rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    cssW = rect.width; cssH = rect.height;
    dpr = Math.min(window.devicePixelRatio || 1, DPR_CAP);
    var w = Math.round(cssW * dpr), h = Math.round(cssH * dpr);
    var sizeChanged = canvas.width !== w || canvas.height !== h;
    if (sizeChanged) { canvas.width = w; canvas.height = h; }
    if (!iw) return;

    // Landscape → cover. Portrait → central 65% of the frame width fills the screen,
    // so the wide split halves stay in view. min() blends the two without a jump.
    var scale = Math.min(Math.max(cssW / iw, cssH / ih), cssW / (iw * PORTRAIT_WIDTH_SHARE));
    var dw = iw * scale, dh = ih * scale;
    var dx = (cssW - dw) / 2, dy = (cssH - dh) / 2;

    // Only the visible intersection is ever decoded or drawn.
    var vx = Math.max(0, dx), vy = Math.max(0, dy);
    var vw = Math.min(cssW, dx + dw) - vx, vh = Math.min(cssH, dy + dh) - vy;
    sx = (vx - dx) / scale; sy = (vy - dy) / scale; sw = vw / scale; sh = vh / scale;
    bx = Math.round(vx * dpr); by = Math.round(vy * dpr);
    bw = Math.round(vw * dpr); bh = Math.round(vh * dpr);
    maxBitmaps = Math.max(16, Math.min(60, Math.floor(BITMAP_BUDGET / (iw * ih * 4))));

    // The edge-fade mask covers exactly that visible area.
    canvas.style.setProperty('--frame-x', vx + 'px');
    canvas.style.setProperty('--frame-y', vy + 'px');
    canvas.style.setProperty('--frame-w', vw + 'px');
    canvas.style.setProperty('--frame-h', vh + 'px');

    // Everything outside the frame stays transparent, so the page background shows through.
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Bitmaps were cut for the old size. Keep showing the current frame (stretched)
    // until its replacement decodes, then rebuild the window.
    var keep = drawn >= 0 ? bitmaps[drawn] : null;
    if (keep) ctx.drawImage(keep, bx, by, bw, bh);
    invalidateBitmaps();
    pumpDecodes();
  }

  var resizeTimer = 0, laidOut = false;
  function onResize() {
    if (!laidOut) { laidOut = true; layout(); return; }   // first measurement: immediately
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(layout, RESIZE_DEBOUNCE);
  }
  if ('ResizeObserver' in window) new ResizeObserver(onResize).observe(canvas);
  else window.addEventListener('resize', onResize);

  /* ---------- Decoding window ---------- */

  var bitmaps = new Array(FRAME_COUNT);   // ImageBitmap (or decoded <img> as a fallback)
  var decoding = new Uint8Array(FRAME_COUNT);
  var activeDecodes = 0;
  var generation = 0;                     // bumps on resize; late decodes for an old size are dropped
  var winLo = 0, winHi = -1;

  function release(i) {
    var b = bitmaps[i];
    if (b && b.close) b.close();
    bitmaps[i] = null;
  }

  function invalidateBitmaps() {
    generation++;
    for (var i = 0; i < FRAME_COUNT; i++) if (bitmaps[i]) release(i);
    drawn = -1;
  }

  // A run of frames around the playhead, longer on the side we are scrolling toward.
  function updateWindow() {
    var c = Math.round(current);
    var ahead = Math.round(maxBitmaps * 0.7), behind = maxBitmaps - 1 - ahead;
    var lo = direction > 0 ? c - behind : c - ahead;
    var hi = direction > 0 ? c + ahead : c + behind;
    if (lo < 0) { hi -= lo; lo = 0; }
    if (hi > LAST) { lo -= hi - LAST; hi = LAST; }
    winLo = Math.max(0, lo); winHi = hi;
  }

  function pumpDecodes() {
    if (!bw) return;
    updateWindow();
    for (var i = 0; i < FRAME_COUNT; i++) {
      if (bitmaps[i] && (i < winLo || i > winHi) && i !== drawn) release(i);
    }
    var c = Math.round(current);

    // Gliding fast: the playhead moves several frames per tick and can't show them all
    // anyway, so first cover the path ahead at that stride, then fill in nearest-first.
    var stride = Math.round(Math.abs(target - current) * SMOOTHING);
    if (stride > 1) {
      for (var s = 1; s * stride <= maxBitmaps && activeDecodes < DECODE_CONCURRENCY; s++) {
        decode(c + s * stride * direction);
      }
    }

    for (var d = 0; d <= maxBitmaps && activeDecodes < DECODE_CONCURRENCY; d++) {
      decode(c + d * direction);
      if (d) decode(c - d * direction);
    }
  }

  function decode(i) {
    if (i < winLo || i > winHi || bitmaps[i] || decoding[i] || !sources[i] || activeDecodes >= DECODE_CONCURRENCY) return;
    decoding[i] = 1; activeDecodes++;
    var gen = generation;
    var job = hasBitmaps
      ? createImageBitmap(sources[i])
      : Promise.resolve(sources[i]);   // already-decoded <img>

    job.then(function (bmp) {
      decoding[i] = 0; activeDecodes--;
      if (gen !== generation || i < winLo || i > winHi) {
        if (bmp.close) bmp.close();
      } else {
        bitmaps[i] = bmp;
        onBitmapReady(i);
      }
      pumpDecodes();
    }, function () {
      decoding[i] = 0; activeDecodes--;
      pumpDecodes();
    });
  }

  function onBitmapReady(i) {
    var want = Math.round(current);
    if (drawn < 0 || Math.abs(i - want) < Math.abs(drawn - want)) draw(i);
    if (drawn >= 0 && resolveFirstFrame) { resolveFirstFrame(); resolveFirstFrame = null; }
  }

  // Exact frame if it is decoded, otherwise the nearest decoded one (never a blank).
  function nearestReady(want) {
    if (bitmaps[want]) return want;
    for (var d = 1; d < FRAME_COUNT; d++) {
      var a = want - d * direction, b = want + d * direction;   // prefer frames already passed
      if (a >= 0 && a <= LAST && bitmaps[a]) return a;
      if (b >= 0 && b <= LAST && bitmaps[b]) return b;
    }
    return -1;
  }

  function draw(i) {
    var b = bitmaps[i];
    if (!b) return;
    ctx.drawImage(b, sx, sy, sw, sh, bx, by, bw, bh);
    drawn = i;
  }

  /* ---------- Static hero (reduced motion / no GSAP) ---------- */

  if (!canScrub) {
    target = current = LAST;
    if (loader) loader.hidden = true;
    requested[LAST] = 1;
    fetchFrame(LAST);
    return;
  }

  /* ---------- Text beats ---------- */

  // [first frame, last frame, fade length in frames]
  var BEATS = [
    { el: hero.querySelector('[data-beat="1"]'), from: 0,   to: 60,  fade: 18, noIn: true },
    { el: hero.querySelector('[data-beat="2"]'), from: 72,  to: 130, fade: 16 },
    { el: hero.querySelector('[data-beat="3"]'), from: 140, to: LAST, fade: 20, noOut: true }
  ];
  var RISE = 36; // px
  // Opening dim: the canvas itself starts at half opacity (the page shows through) and is
  // fully lit by DIM_END. Opacity, not a coloured overlay, so it can't shift the brown.
  var DIM_MAX = 0.5, DIM_END = 56;
  var dimValue = -1;

  function smooth(t) { return t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t); }

  // Opacity + transform only. Hidden beats stay painted (so showing one never costs a
  // first paint mid-scroll) but are made inert: not clickable, not focusable, not read out.
  var scrolled = false;

  function updateBeats(f) {
    // The looping scroll hint is only for a visitor resting at the top; once the
    // playhead moves it pauses, so it never competes with scrolling for frames.
    var s = f > 0.5;
    if (s !== scrolled) { scrolled = s; hero.classList.toggle('has-scrolled', s); }

    var d = DIM_MAX * (1 - smooth(f / DIM_END));
    if (d !== dimValue) { dimValue = d; canvas.style.opacity = (1 - d).toFixed(3); }

    for (var b = 0; b < BEATS.length; b++) {
      var beat = BEATS[b];
      if (!beat.el) continue;
      var tin = beat.noIn ? 1 : smooth((f - beat.from) / beat.fade);
      var tout = beat.noOut ? 1 : smooth((beat.to - f) / beat.fade);
      var o = Math.min(tin, tout);
      var y = tin < 1 ? (1 - tin) * RISE : -(1 - tout) * RISE;
      if (beat.o === o && beat.y === y) continue;
      beat.o = o; beat.y = y;
      // Never exactly 0: Chrome skips painting fully transparent layers, which would push a
      // beat's first paint to the moment it appears, mid-scroll.
      beat.el.style.opacity = Math.max(o, 0.001).toFixed(3);
      beat.el.style.transform = 'translate3d(0,' + y.toFixed(1) + 'px,0)';
      var shown = o >= 0.01;
      if (shown !== beat.shown) { beat.shown = shown; beat.el.inert = !shown; }
    }
  }

  /* ---------- Playhead: driven by GSAP's ticker (the page's only rAF loop) ---------- */

  var lastWant = -1;

  function tick(time, deltaTime) {
    if (current === target) return;
    var k = 1 - Math.pow(1 - SMOOTHING, Math.min(deltaTime, 64) / 16.667);
    current += (target - current) * k;
    if (Math.abs(target - current) < 0.01) current = target;

    var want = Math.round(current);
    if (want !== lastWant) {
      lastWant = want;
      pumpDecodes();
      var best = nearestReady(want);
      // Never step backwards against the scroll (e.g. from a stand-in that ran ahead); hold instead.
      var backwards = drawn >= 0 && (best - drawn) * direction < 0;
      if (best >= 0 && best !== drawn && !backwards) draw(best);   // redraw only when the frame index changes
    }
    updateBeats(current);
  }

  var gsap = window.gsap;
  gsap.registerPlugin(window.ScrollTrigger);
  // Added after Lenis (main.js registers it with priority), so each tick sees this frame's scroll.
  gsap.ticker.add(tick);

  window.ScrollTrigger.create({
    trigger: hero,
    start: 'top top',
    end: function () { return '+=' + Math.round(window.innerHeight * PIN_DISTANCE); },
    pin: true,
    anticipatePin: 1,
    invalidateOnRefresh: true,
    onUpdate: function (self) {
      var t = self.progress * LAST;
      if (Math.abs(t - target) > 0.001) direction = t > target ? 1 : -1;
      target = t;
    },
    // Promote the text layers only while the hero is actually animating.
    onToggle: function (self) { hero.classList.toggle('is-scrubbing', self.isActive); }
  });

  updateBeats(0);

  /* ---------- Boot ---------- */

  // Frame 1 first (it is preloaded from <head>), the rest once the page has loaded.
  requested[0] = 1;
  fetchFrame(0).then(function () {
    var start = function () { for (var w = 0; w < FETCH_CONCURRENCY; w++) fetchWorker(); };
    if (document.readyState === 'complete') start();
    else window.addEventListener('load', start, { once: true });
  });
})();
